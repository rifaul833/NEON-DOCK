globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/l7amQ0glG9FTcMsXWh4On/_buildManifest.js",
    "static/l7amQ0glG9FTcMsXWh4On/_ssgManifest.js",
    "static/l7amQ0glG9FTcMsXWh4On/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/0e858m77o3vc2.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-01zeubdsi663x.js"
  ]
};
