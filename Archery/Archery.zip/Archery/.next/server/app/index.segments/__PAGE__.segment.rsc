1:"$Sreact.fragment"
2:I[31363,["/games/archery/_next/static/chunks/0dbhjjzl8qfwv.js","/games/archery/_next/static/chunks/0yjp2q..xa2r1.js"],"default"]
3:I[97367,["/games/archery/_next/static/chunks/0dbhjjzl8qfwv.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/games/archery/_next/static/chunks/0yjp2q..xa2r1.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"l7amQ0glG9FTcMsXWh4On"}
5:null
